﻿namespace Il2CppDumper
{
    public class CustomAttributeReaderVisitor
    {
        public int CtorIndex;
        public AttributeArgument[] Arguments;
        public AttributeArgument[] Fields;
        public AttributeArgument[] Properties;
    }
}
