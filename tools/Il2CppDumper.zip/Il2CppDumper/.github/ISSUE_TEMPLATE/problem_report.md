---
name: Problem report
about: Problem report
title: ''
labels: ''
assignees: ''

---

Note: if you do not provide all of the following information I will directly ignore and close this issue

- Il2CppDumper version

- Target Unity version (optional)

- Describe the issue

- Upload executable file and global-metadata.dat
