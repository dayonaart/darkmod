---
name: 问题报告
about: 中文问题报告
title: ''
labels: ''
assignees: ''

---

请注意：如果你没有提供以下所有信息我将会直接无视并关闭这个issue

- Il2CppDumper版本

- 目标Unity版本 (可以不填)

- 问题描述

- 上传可执行文件和global-metadata.dat
