﻿namespace Il2CppDumper
{
    public class BlobValue
    {
        public object Value;
        public Il2CppTypeEnum il2CppTypeEnum;
        public Il2CppType EnumType;
    }
}
