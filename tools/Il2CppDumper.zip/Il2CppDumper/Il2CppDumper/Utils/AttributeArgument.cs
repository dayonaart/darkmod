﻿namespace Il2CppDumper
{
    public class AttributeArgument
    {
        public BlobValue Value;
        public int Index;
    }
}
